////////////////////////////////////////////////////////////////////////////////
///                                  cake.c                                  ///
////////////////////////////////////////////////////////////////////////////////
#include "list.h"
#include "cake.h"

/*
 * The documentation for the functions to be defined in this file appears in
 * cake.h.
 */


#if   !defined(GRADE_INSERT_HEAD) && 	\
      !defined(GRADE_INSERT_TAIL) && 	\
      !defined(GRADE_LENGTH) && 	\
      !defined(GRADE_FREE_LIST) && 	\
      !defined(GRADE_ELIMINATE)
Node * create_players(int numPlayers)
{

}
#endif


#if   !defined(GRADE_INSERT_HEAD) && 	\
      !defined(GRADE_INSERT_TAIL) && 	\
      !defined(GRADE_LENGTH) && 	\
      !defined(GRADE_FREE_LIST) && 	\
      !defined(GRADE_CREATE)
int eliminate(int numPlayers, int interval)
{

}
#endif
////////////////////////////////////////////////////////////////////////////////
///                                END OF FILE                               ///
////////////////////////////////////////////////////////////////////////////////
